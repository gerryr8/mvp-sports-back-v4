package com.example.mvpsportsbackendv2.models;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import javax.validation.constraints.Size;
import java.sql.Blob;

@Entity
@Table(name="products")
public class ProductModel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(unique = true, nullable = false)
    int product_number;

    @Size(min = 4, max = 100)
    @NotEmpty (message = "Completa este campo")
    String name;

    @NotEmpty (message = "Completa este campo")
    String price;

    @NotEmpty (message = "Completa este campo")
    String stock;

    @Size(min = 8, max = 250, message = "No más de 250 caracteres")
    @NotEmpty (message = "Completa este campo")
    String description;

    String thumbnail;

    @NotEmpty (message = "Completa este campo")
    String image;

    @NotEmpty (message = "Completa este campo")
    String weight;

    @NotEmpty (message = "Completa este campo")
    String category;

    public ProductModel() {
    }

    public int getProduct_number() {
        return product_number;
    }

    public void setProduct_number(int product_number) {
        this.product_number = product_number;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public String getStock() {
        return stock;
    }

    public void setStock(String stock) {
        this.stock = stock;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getThumbnail() {
        return thumbnail;
    }

    public void setThumbnail(String thumbnail) {
        this.thumbnail = thumbnail;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }
}
