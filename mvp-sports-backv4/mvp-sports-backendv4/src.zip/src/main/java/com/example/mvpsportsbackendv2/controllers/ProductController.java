package com.example.mvpsportsbackendv2.controllers;

import com.example.mvpsportsbackendv2.models.ProductModel;
import com.example.mvpsportsbackendv2.repositories.ProductRepository;
import com.example.mvpsportsbackendv2.services.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.Optional;

@RestController
@RequestMapping("/products")

public class ProductController {

    @Autowired
    ProductService productService;

    @Autowired
    ProductRepository productRepository;


    @PostMapping()
    public ProductModel saveProduct(@Valid @RequestBody ProductModel name){

        return this.productService.saveProduct(name);
    }

    @GetMapping()
    public @ResponseBody Iterable<ProductModel> getProducts(){
        return productService.getProducts();
    }
    @GetMapping( path = "/{product_number}")
    public Optional<ProductModel> findById(@PathVariable("product_number") Long product_number) {
        return this.productService.findById(product_number);
    }

    @RequestMapping(value="/{product_number}", method=RequestMethod.DELETE)
    public String deleteById(@PathVariable("product_number")Long product_number){

        boolean ok = this.productService.deleteById(product_number);
        if (ok){
            return "producto eliminado" + product_number;
        }else{
            return "no se pudo eliminar el producto" + product_number;

        }
    }

}
