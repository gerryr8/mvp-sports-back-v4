package com.example.mvpsportsbackendv2.controllers;

import java.util.ArrayList;
import java.util.Optional;

import com.example.mvpsportsbackendv2.models.UsuarioModel;
import com.example.mvpsportsbackendv2.services.UsuarioService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;


@RestController
@RequestMapping("/usuario")
public class UsuarioController {
    @Autowired
    UsuarioService usuarioService;

    @GetMapping()
    public ArrayList<UsuarioModel> obtenerUsuarios(){
        return usuarioService.obtenerUsuarios();
    }

    @PostMapping()
    public UsuarioModel guardarUsuario(@Valid @RequestBody UsuarioModel email){

        return this.usuarioService.guardarUsuario(email);
    }

    @GetMapping( path = "/{id}")
    public Optional<UsuarioModel> obtenerUsuarioPorId(@PathVariable("id") Long customer_id) {
        return this.usuarioService.obtenerPorId(customer_id);
    }


    @DeleteMapping( path = "/{id}")
    public String eliminarPorId(@PathVariable("id") Long customer_id){
        boolean ok = this.usuarioService.eliminarUsuario(customer_id);
        if (ok){
            return "Se eliminó el usuario con id " + customer_id;
        }else{
            return "No pudo eliminar el usuario con id" + customer_id;
        }
    }

    @GetMapping("/addp")
    public String addp(){
        return "addp";
    }

}