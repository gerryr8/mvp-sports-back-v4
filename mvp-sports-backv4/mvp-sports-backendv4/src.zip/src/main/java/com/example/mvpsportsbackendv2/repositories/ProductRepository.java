package com.example.mvpsportsbackendv2.repositories;

import com.example.mvpsportsbackendv2.models.ProductModel;
import org.springframework.data.repository.CrudRepository;

public interface ProductRepository extends CrudRepository<ProductModel, Long> {

    @Override
    Iterable<ProductModel> findAll();
}
